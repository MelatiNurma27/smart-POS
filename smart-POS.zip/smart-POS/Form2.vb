﻿Imports System.Data.Odbc

Public Class Form2
    Public conn As OdbcConnection
    Public cmd As OdbcCommand
    Public reader As OdbcDataReader
    Public connString As String = "DSN=koneksi_dblatihan2"

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ErrorProvider1.Clear()
        LoadKategori()
        LoadSatuan()

        SetKodeBarangOtomatis()
    End Sub

    Private Sub OpenConnection()
        conn = New OdbcConnection(connString)
        If conn.State = ConnectionState.Closed Then conn.Open()
    End Sub

    Private Sub CloseConnection()
        If conn.State = ConnectionState.Open Then conn.Close()
    End Sub

    Private Sub SetKodeBarangOtomatis()
        Try
            OpenConnection()
            Dim queryKode As String = "SELECT RIGHT(MAX(Kode_Barang), 3) FROM tblbarang"
            cmd = New OdbcCommand(queryKode, conn)
            Dim maxKode As String = cmd.ExecuteScalar().ToString()

            Dim kodeBaru As String
            If String.IsNullOrEmpty(maxKode) Then
                kodeBaru = "BRG001"
            Else
                Dim nomor As Integer = Integer.Parse(maxKode) + 1
                kodeBaru = "BRG" & nomor.ToString("D3")
            End If
            txtKodeBarang.Text = kodeBaru

        Catch ex As Exception
            MessageBox.Show("Gagal menghasilkan kode barang otomatis: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub LoadKategori()
        Try
            OpenConnection()
            Dim query As String = "SELECT Jenis FROM tbljenis_barang"
            cmd = New OdbcCommand(query, conn)
            reader = cmd.ExecuteReader
            cmbKategoriBarang.Items.Clear()
            While reader.Read()
                cmbKategoriBarang.Items.Add(reader("Jenis").ToString())
            End While
            reader.Close()
        Catch ex As Exception
            MessageBox.Show("Gagal memuat kategori: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub LoadSatuan()
        Try
            OpenConnection()
            Dim query As String = "SELECT satuan FROM tblsatuan"
            cmd = New OdbcCommand(query, conn)
            reader = cmd.ExecuteReader
            cmbSatuanBarang.Items.Clear()
            While reader.Read()
                cmbSatuanBarang.Items.Add(reader("satuan").ToString())
            End While
            reader.Close()
        Catch ex As Exception
            MessageBox.Show("Gagal memuat satuan: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub btnSimpanKategori_Click(sender As Object, e As EventArgs) Handles btnSimpanKategori.Click
        If String.IsNullOrEmpty(txtJenisProduk.Text) Then
            ErrorProvider1.SetError(txtJenisProduk, "Masukkan kategori.")
            Return
        Else
            ErrorProvider1.SetError(txtJenisProduk, "")
        End If

        Try
            OpenConnection()
            Dim query As String = "INSERT INTO tbljenis_barang (Jenis) VALUES (?)"
            cmd = New OdbcCommand(query, conn)
            cmd.Parameters.AddWithValue("@Jenis", txtJenisProduk.Text)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Kategori berhasil disimpan.")
            LoadKategori()
            txtJenisProduk.Clear()
        Catch ex As OdbcException When ex.ErrorCode = -2146232060
            MessageBox.Show("Kategori sudah ada.")
        Catch ex As Exception
            MessageBox.Show("Gagal menyimpan kategori: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub btnTambahSatuan_Click(sender As Object, e As EventArgs) Handles btnTambahSatuan.Click
        If String.IsNullOrEmpty(txtSatuan.Text) Then
            ErrorProvider1.SetError(txtSatuan, "Masukkan satuan.")
            Return
        Else
            ErrorProvider1.SetError(txtSatuan, "")
        End If

        Try
            OpenConnection()
            Dim query As String = "INSERT INTO tblsatuan (satuan) VALUES (?)"
            cmd = New OdbcCommand(query, conn)
            cmd.Parameters.AddWithValue("@satuan", txtSatuan.Text)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Satuan berhasil disimpan.")
            LoadSatuan()
            txtSatuan.Clear()
        Catch ex As OdbcException When ex.ErrorCode = -2146232060
            MessageBox.Show("Satuan sudah ada.")
        Catch ex As Exception
            MessageBox.Show("Gagal menyimpan satuan: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub btnSimpanProduk_Click(sender As Object, e As EventArgs) Handles btnSimpanProduk.Click
        Dim isValid As Boolean = True

        If String.IsNullOrEmpty(txtNamaBarang.Text) Then
            ErrorProvider1.SetError(txtNamaBarang, "Nama barang harus diisi.")
            isValid = False
        Else
            ErrorProvider1.SetError(txtNamaBarang, "")
        End If

        If String.IsNullOrEmpty(cmbKategoriBarang.Text) Then
            ErrorProvider1.SetError(cmbKategoriBarang, "Kategori barang harus dipilih.")
            isValid = False
        Else
            ErrorProvider1.SetError(cmbKategoriBarang, "")
        End If

        If String.IsNullOrEmpty(cmbSatuanBarang.Text) Then
            ErrorProvider1.SetError(cmbSatuanBarang, "Satuan barang harus dipilih.")
            isValid = False
        Else
            ErrorProvider1.SetError(cmbSatuanBarang, "")
        End If

        If String.IsNullOrEmpty(txtHargaBeli.Text) OrElse Not IsNumeric(txtHargaBeli.Text) Then
            ErrorProvider1.SetError(txtHargaBeli, "Harga beli harus diisi dengan angka.")
            isValid = False
        Else
            ErrorProvider1.SetError(txtHargaBeli, "")
        End If

        If String.IsNullOrEmpty(txtHargaJual.Text) OrElse Not IsNumeric(txtHargaJual.Text) Then
            ErrorProvider1.SetError(txtHargaJual, "Harga jual harus diisi dengan angka.")
            isValid = False
        Else
            ErrorProvider1.SetError(txtHargaJual, "")
        End If

        If String.IsNullOrEmpty(txtSaldoAwal.Text) OrElse Not IsNumeric(txtSaldoAwal.Text) Then
            ErrorProvider1.SetError(txtSaldoAwal, "Saldo awal harus diisi dengan angka.")
            isValid = False
        Else
            ErrorProvider1.SetError(txtSaldoAwal, "")
        End If

        If Not isValid Then
            MessageBox.Show("Harap lengkapi semua data dengan benar.", "Validasi Gagal", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Try
            OpenConnection()

            Dim query As String = "INSERT INTO tblbarang (Kode_Barang, Nama_Barang, Jenis, Satuan, Harga_Beli, Harga_Jual, Stock) VALUES (?, ?, ?, ?, ?, ?, ?)"
            cmd = New OdbcCommand(query, conn)
            cmd.Parameters.AddWithValue("@Kode_Barang", txtKodeBarang.Text)
            cmd.Parameters.AddWithValue("@Nama_Barang", txtNamaBarang.Text)
            cmd.Parameters.AddWithValue("@Jenis", cmbKategoriBarang.Text)
            cmd.Parameters.AddWithValue("@Satuan", cmbSatuanBarang.Text)
            cmd.Parameters.AddWithValue("@Harga_Beli", txtHargaBeli.Text)
            cmd.Parameters.AddWithValue("@Harga_Jual", txtHargaJual.Text)
            cmd.Parameters.AddWithValue("@Stock", txtSaldoAwal.Text)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Produk berhasil disimpan.")

            txtNamaBarang.Clear()
            txtHargaBeli.Clear()
            txtHargaJual.Clear()
            txtSaldoAwal.Clear()
            cmbKategoriBarang.SelectedIndex = -1
            cmbSatuanBarang.SelectedIndex = -1

            SetKodeBarangOtomatis()

        Catch ex As Exception
            MessageBox.Show("Gagal menyimpan produk: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub


    Private Sub TransaksiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TransaksiToolStripMenuItem.Click
        Dim formTransaksi As New form1()
        formTransaksi.Show()
        Me.Hide()
    End Sub

    Private Sub ProdukToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProdukToolStripMenuItem.Click
        Me.Show()
    End Sub
End Class
