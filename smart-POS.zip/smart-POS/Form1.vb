﻿Imports System.Data.Odbc

Public Class form1
    Public conn As OdbcConnection
    Public cmd As OdbcCommand
    Public dr As OdbcDataReader

    Sub koneksi()
        conn = New OdbcConnection("Dsn=koneksi_dblatihan2;Database=db_latihan2;Uid=root;Pwd=")
        Try
            If conn.State = ConnectionState.Closed Then
                conn.Open()
                MsgBox("Koneksi berhasil")
            End If
        Catch ex As Exception
            MsgBox("Koneksi gagal: " & ex.Message)
        End Try
    End Sub

    Sub IsiComboBox()
        Try
            Dim query As String = "SELECT kode_pelanggan FROM tbl_pelanggan"
            cmd = New OdbcCommand(query, conn)
            dr = cmd.ExecuteReader()
            cmbPelanggan.Items.Clear()
            While dr.Read()
                cmbPelanggan.Items.Add(dr("kode_pelanggan").ToString())
            End While
            dr.Close()
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
        Try
            Dim query As String = "SELECT Nama_Barang FROM tblBarang"
            cmd = New OdbcCommand(query, conn)
            dr = cmd.ExecuteReader()
            cmbBarang.Items.Clear()
            While dr.Read()
                cmbBarang.Items.Add(dr("Nama_Barang").ToString())
            End While
            dr.Close()
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub TampilkanSemuaDataPenjualan()
        Dim dt As New DataTable()
        Dim query As String = "SELECT * FROM tbl_penjualan_rinci"

        Try
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If

            cmd = New OdbcCommand(query, conn)

            Using adapter As New OdbcDataAdapter(cmd)
                adapter.Fill(dt)
            End Using

            DataGridView1.DataSource = dt

            DataGridView1.Columns("id").HeaderText = "ID"
            DataGridView1.Columns("faktur_penjualan").HeaderText = "Faktur Penjualan"
            DataGridView1.Columns("kode_barang").HeaderText = "Kode Barang"
            DataGridView1.Columns("harga_jual").HeaderText = "Harga Jual"
            DataGridView1.Columns("jumlah").HeaderText = "Jumlah"
            DataGridView1.Columns("sub_total").HeaderText = "Sub Total"

        Catch ex As Exception
            MsgBox("Kesalahan saat menampilkan data: " & ex.Message)
        End Try
    End Sub

    Sub hitungTotal()
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        Dim totalQuery As String = "SELECT SUM(sub_total) AS TotalFaktur FROM tbl_penjualan_rinci WHERE faktur_penjualan = ?"
        cmd = New OdbcCommand(totalQuery, conn)
        cmd.Parameters.AddWithValue("?", txtFakturPenjualan.Text)

        Try
            Dim total As Object = cmd.ExecuteScalar()

            If total IsNot DBNull.Value Then
                txtTotal.Text = total
            Else
                txtTotal.Text = ""
            End If

        Catch ex As Exception
            MsgBox("Kesalahan saat menghitung total: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Sub AutoIncrementFaktur()
        Dim query As String = "SELECT faktur_penjualan FROM tbl_penjualan ORDER BY faktur_penjualan DESC LIMIT 1"
        Dim lastFaktur As String = ""

        Try
            If conn.State = ConnectionState.Closed Then conn.Open()
            cmd = New OdbcCommand(query, conn)
            dr = cmd.ExecuteReader()

            If dr.Read() Then
                lastFaktur = dr("faktur_penjualan").ToString()
            End If
            dr.Close()

            If lastFaktur <> "" Then
                Dim num As Integer = Integer.Parse(lastFaktur.Substring(lastFaktur.Length - 4)) + 1
                txtFakturPenjualan.Text = "F" & DateTime.Now.ToString("yyMMdd") & num.ToString("D4")
            Else
                txtFakturPenjualan.Text = "F" & DateTime.Now.ToString("yyMMdd") & "0001"
            End If

        Catch ex As Exception
            MsgBox("Kesalahan saat mengisi nomor faktur: " & ex.Message)
        End Try
    End Sub

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        koneksi()
        TampilkanSemuaDataPenjualan()
        IsiComboBox()
        AutoIncrementFaktur()
    End Sub

    Private Sub cmbPelanggan_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbPelanggan.SelectedIndexChanged
        Try
            Dim selectedKode As String = cmbPelanggan.SelectedItem.ToString()
            Dim query As String = "SELECT nama_pelanggan FROM tbl_pelanggan WHERE kode_pelanggan = ?"
            cmd = New OdbcCommand(query, conn)
            cmd.Parameters.Add(New OdbcParameter("namaPelanggan", selectedKode))
            dr = cmd.ExecuteReader()
            If dr.Read() Then
                txtNamaPelanggan.Text = dr("nama_pelanggan").ToString()
            End If
            dr.Close()
        Catch ex As Exception
            MsgBox("Error:" & ex.Message)
        End Try
    End Sub

    Private Sub cmbBarang_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbBarang.SelectedIndexChanged
        Try
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If
            Dim selectedBarang As String = cmbBarang.SelectedItem.ToString()
            Dim query As String = "SELECT harga_beli, kode_barang, jenis, harga_jual FROM tblbarang WHERE Nama_Barang = ?"
            cmd = New OdbcCommand(query, conn)
            cmd.Parameters.Add(New OdbcParameter("namaBarang", selectedBarang))
            dr = cmd.ExecuteReader()

            If dr.Read() Then
                txtKodeBarang.Text = dr("kode_barang").ToString()
                txtJenis.Text = dr("jenis").ToString()
                txtHargaBeli.Text = dr("harga_beli").ToString()
                txtHargaJual.Text = dr("harga_jual").ToString()
            End If

            dr.Close()
            If txtJumlahBeli.Text IsNot "" Then
                Dim jumlahbeli As Integer = Integer.Parse(txtJumlahBeli.Text)
                Dim hargajual As Double = Double.Parse(txtHargaJual.Text)
                Dim subtotal As Double = jumlahbeli * hargajual
                txtSubTotal.Text = subtotal
            End If
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub txtJumlahBeli_TextChanged(sender As Object, e As EventArgs) Handles txtJumlahBeli.TextChanged
        If txtJumlahBeli.Text IsNot "" Then
            Try
                Dim jumlahbeli As Integer = Integer.Parse(txtJumlahBeli.Text)
                Dim hargajual As Double = Double.Parse(txtHargaJual.Text)
                Dim subtotal As Double = jumlahbeli * hargajual
                txtSubTotal.Text = subtotal
            Catch ex As Exception
                MsgBox("Error: Masukkan Angka!")
            End Try
        Else
            txtSubTotal.Text = ""
        End If
    End Sub

    Sub buatpenjualan()
        Dim nofaktur = txtFakturPenjualan.Text
        Dim tgl = DateTimePicker1.Value
        Dim kodepelanggan = cmbPelanggan.Text
        Dim totalpembelian = txtTotal.Text
        Dim query As String = "INSERT INTO tbl_penjualan (faktur_penjualan, tgl_penjualan, kode_pelanggan, total) VALUES (?, ?, ?, ?)"
        Try
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If
            cmd = New OdbcCommand(query, conn)
            cmd.Parameters.AddWithValue("?", nofaktur)
            cmd.Parameters.AddWithValue("?", tgl)
            cmd.Parameters.AddWithValue("?", kodepelanggan)
            cmd.Parameters.AddWithValue("?", totalpembelian)
            cmd.ExecuteNonQuery()
            MsgBox("Data penjualan berhasil disimpan ke dalam tabel.")
        Catch ex As Exception
            MsgBox("Kesalahan saat menyimpan data: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Sub simpandetail()
        Dim nofaktur = txtFakturPenjualan.Text
        Dim kodebarang = txtKodeBarang.Text
        Dim hargajual = txtHargaJual.Text
        Dim jumlahbeli = txtJumlahBeli.Text
        Dim subtotal = txtSubTotal.Text
        Dim query As String = "INSERT INTO tbl_penjualan_rinci (faktur_penjualan, kode_barang, harga_jual, jumlah, sub_total) VALUES (?, ?, ?, ?, ?)"

        Try
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If
            cmd = New OdbcCommand(query, conn)
            cmd.Parameters.AddWithValue("?", nofaktur)
            cmd.Parameters.AddWithValue("?", kodebarang)
            cmd.Parameters.AddWithValue("?", hargajual)
            cmd.Parameters.AddWithValue("?", jumlahbeli)
            cmd.Parameters.AddWithValue("?", subtotal)
            cmd.ExecuteNonQuery()
            MsgBox("Data detail penjualan berhasil disimpan ke dalam tabel.")
        Catch ex As Exception
            MsgBox("Kesalahan saat menyimpan data detail penjualan: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Sub simpanpenjualan()
        Dim nofaktur = txtFakturPenjualan.Text
        Dim totalpembelian = txtTotal.Text

        Dim query As String = "UPDATE tbl_penjualan SET total = ? WHERE faktur_penjualan = ?"
        Try
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If

            cmd = New OdbcCommand(query, conn)
            cmd.Parameters.AddWithValue("?", totalpembelian)
            cmd.Parameters.AddWithValue("?", nofaktur)
            cmd.ExecuteNonQuery()

            MsgBox("Total penjualan berhasil diperbarui di tabel.")
        Catch ex As Exception
            MsgBox("Kesalahan saat memperbarui data: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click
        Call simpanpenjualan()
        TampilkanSemuaDataPenjualan()
        AutoIncrementFaktur()
        hitungTotal()
        btnBuat.Text = "Buat"
        DateTimePicker1.Enabled = True
        cmbPelanggan.Enabled = True

        cmbPelanggan.Text = ""
        cmbBarang.Text = ""
        txtJumlahBeli.Clear()
        txtNamaPelanggan.Clear()
        txtKodeBarang.Clear()
        txtJenis.Clear()
        txtHargaBeli.Clear()
        txtHargaJual.Clear()
    End Sub

    Private Sub btnBuat_Click(sender As Object, e As EventArgs) Handles btnBuat.Click
        If String.IsNullOrWhiteSpace(txtNamaPelanggan.Text) Then
            MessageBox.Show("Nama pelanggan tidak boleh kosong.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        If btnBuat.Text = "Buat" Then
            Call buatpenjualan()
            Call simpandetail()
            TampilkanSemuaDataPenjualan()
            hitungTotal()
            btnBuat.Text = "Tambah"
            DateTimePicker1.Enabled = False
            cmbPelanggan.Enabled = False
        Else
            Call simpandetail()
            TampilkanSemuaDataPenjualan()
            hitungTotal()
        End If
    End Sub

    Private Sub TransaksiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TransaksiToolStripMenuItem.Click
        Me.Show()
    End Sub
    Private Sub ProdukToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProdukToolStripMenuItem.Click
        Dim formProduk As New Form2()
        formProduk.Show()
    End Sub
End Class
