﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TransaksiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProdukToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtJenisProduk = New System.Windows.Forms.TextBox()
        Me.txtSatuan = New System.Windows.Forms.TextBox()
        Me.btnSimpanKategori = New System.Windows.Forms.Button()
        Me.btnTambahSatuan = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtKodeBarang = New System.Windows.Forms.TextBox()
        Me.txtNamaBarang = New System.Windows.Forms.TextBox()
        Me.txtHargaBeli = New System.Windows.Forms.TextBox()
        Me.cmbKategoriBarang = New System.Windows.Forms.ComboBox()
        Me.cmbSatuanBarang = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtHargaJual = New System.Windows.Forms.TextBox()
        Me.txtSaldoAwal = New System.Windows.Forms.TextBox()
        Me.btnSimpanProduk = New System.Windows.Forms.Button()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.MenuStrip1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TransaksiToolStripMenuItem, Me.ProdukToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1049, 28)
        Me.MenuStrip1.TabIndex = 30
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TransaksiToolStripMenuItem
        '
        Me.TransaksiToolStripMenuItem.Name = "TransaksiToolStripMenuItem"
        Me.TransaksiToolStripMenuItem.Size = New System.Drawing.Size(82, 24)
        Me.TransaksiToolStripMenuItem.Text = "Transaksi"
        '
        'ProdukToolStripMenuItem
        '
        Me.ProdukToolStripMenuItem.Name = "ProdukToolStripMenuItem"
        Me.ProdukToolStripMenuItem.Size = New System.Drawing.Size(69, 24)
        Me.ProdukToolStripMenuItem.Text = "Produk"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Label1.Location = New System.Drawing.Point(359, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(348, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Form Tambah Kategori Satuan Produk"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label2.Location = New System.Drawing.Point(78, 114)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 16)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "Jenis Produk"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label3.Location = New System.Drawing.Point(78, 166)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 16)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Satuan"
        '
        'txtJenisProduk
        '
        Me.txtJenisProduk.Location = New System.Drawing.Point(175, 111)
        Me.txtJenisProduk.Name = "txtJenisProduk"
        Me.txtJenisProduk.Size = New System.Drawing.Size(211, 22)
        Me.txtJenisProduk.TabIndex = 33
        '
        'txtSatuan
        '
        Me.txtSatuan.Location = New System.Drawing.Point(175, 163)
        Me.txtSatuan.Name = "txtSatuan"
        Me.txtSatuan.Size = New System.Drawing.Size(211, 22)
        Me.txtSatuan.TabIndex = 34
        '
        'btnSimpanKategori
        '
        Me.btnSimpanKategori.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnSimpanKategori.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSimpanKategori.Location = New System.Drawing.Point(443, 106)
        Me.btnSimpanKategori.Name = "btnSimpanKategori"
        Me.btnSimpanKategori.Size = New System.Drawing.Size(130, 32)
        Me.btnSimpanKategori.TabIndex = 35
        Me.btnSimpanKategori.Text = "Simpan Kategori"
        Me.btnSimpanKategori.UseVisualStyleBackColor = False
        '
        'btnTambahSatuan
        '
        Me.btnTambahSatuan.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnTambahSatuan.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnTambahSatuan.Location = New System.Drawing.Point(443, 158)
        Me.btnTambahSatuan.Name = "btnTambahSatuan"
        Me.btnTambahSatuan.Size = New System.Drawing.Size(130, 32)
        Me.btnTambahSatuan.TabIndex = 36
        Me.btnTambahSatuan.Text = "Tambah Satuan"
        Me.btnTambahSatuan.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Label4.Location = New System.Drawing.Point(429, 241)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(202, 25)
        Me.Label4.TabIndex = 37
        Me.Label4.Text = "Form Tambah Produk"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label5.Location = New System.Drawing.Point(78, 327)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 16)
        Me.Label5.TabIndex = 38
        Me.Label5.Text = "Kode Barang"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label6.Location = New System.Drawing.Point(78, 371)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(91, 16)
        Me.Label6.TabIndex = 39
        Me.Label6.Text = "Nama Barang"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label7.Location = New System.Drawing.Point(78, 454)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 16)
        Me.Label7.TabIndex = 40
        Me.Label7.Text = "Satuan Barang"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label8.Location = New System.Drawing.Point(78, 413)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 16)
        Me.Label8.TabIndex = 41
        Me.Label8.Text = "Kategori Barang"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label9.Location = New System.Drawing.Point(78, 495)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(71, 16)
        Me.Label9.TabIndex = 42
        Me.Label9.Text = "Harga Beli"
        '
        'txtKodeBarang
        '
        Me.txtKodeBarang.Location = New System.Drawing.Point(192, 324)
        Me.txtKodeBarang.Name = "txtKodeBarang"
        Me.txtKodeBarang.ReadOnly = True
        Me.txtKodeBarang.Size = New System.Drawing.Size(194, 22)
        Me.txtKodeBarang.TabIndex = 43
        '
        'txtNamaBarang
        '
        Me.txtNamaBarang.Location = New System.Drawing.Point(192, 368)
        Me.txtNamaBarang.Name = "txtNamaBarang"
        Me.txtNamaBarang.Size = New System.Drawing.Size(194, 22)
        Me.txtNamaBarang.TabIndex = 44
        '
        'txtHargaBeli
        '
        Me.txtHargaBeli.Location = New System.Drawing.Point(192, 492)
        Me.txtHargaBeli.Name = "txtHargaBeli"
        Me.txtHargaBeli.Size = New System.Drawing.Size(194, 22)
        Me.txtHargaBeli.TabIndex = 45
        '
        'cmbKategoriBarang
        '
        Me.cmbKategoriBarang.FormattingEnabled = True
        Me.cmbKategoriBarang.Location = New System.Drawing.Point(192, 410)
        Me.cmbKategoriBarang.Name = "cmbKategoriBarang"
        Me.cmbKategoriBarang.Size = New System.Drawing.Size(194, 24)
        Me.cmbKategoriBarang.TabIndex = 46
        '
        'cmbSatuanBarang
        '
        Me.cmbSatuanBarang.FormattingEnabled = True
        Me.cmbSatuanBarang.Location = New System.Drawing.Point(192, 451)
        Me.cmbSatuanBarang.Name = "cmbSatuanBarang"
        Me.cmbSatuanBarang.Size = New System.Drawing.Size(194, 24)
        Me.cmbSatuanBarang.TabIndex = 47
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label10.Location = New System.Drawing.Point(457, 324)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(73, 16)
        Me.Label10.TabIndex = 48
        Me.Label10.Text = "Harga Jual"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label11.Location = New System.Drawing.Point(455, 359)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(75, 16)
        Me.Label11.TabIndex = 49
        Me.Label11.Text = "Saldo Awal"
        '
        'txtHargaJual
        '
        Me.txtHargaJual.Location = New System.Drawing.Point(554, 321)
        Me.txtHargaJual.Name = "txtHargaJual"
        Me.txtHargaJual.Size = New System.Drawing.Size(209, 22)
        Me.txtHargaJual.TabIndex = 50
        '
        'txtSaldoAwal
        '
        Me.txtSaldoAwal.Location = New System.Drawing.Point(554, 356)
        Me.txtSaldoAwal.Name = "txtSaldoAwal"
        Me.txtSaldoAwal.Size = New System.Drawing.Size(209, 22)
        Me.txtSaldoAwal.TabIndex = 51
        '
        'btnSimpanProduk
        '
        Me.btnSimpanProduk.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnSimpanProduk.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSimpanProduk.Location = New System.Drawing.Point(443, 492)
        Me.btnSimpanProduk.Name = "btnSimpanProduk"
        Me.btnSimpanProduk.Size = New System.Drawing.Size(130, 32)
        Me.btnSimpanProduk.TabIndex = 52
        Me.btnSimpanProduk.Text = "Simpan Produk"
        Me.btnSimpanProduk.UseVisualStyleBackColor = False
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global._8_Modifying_Form.My.Resources.Resources.Green_Illustration_Log_In_Page_Desktop_Prototype__12_
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1049, 582)
        Me.Controls.Add(Me.btnSimpanProduk)
        Me.Controls.Add(Me.txtSaldoAwal)
        Me.Controls.Add(Me.txtHargaJual)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.cmbSatuanBarang)
        Me.Controls.Add(Me.cmbKategoriBarang)
        Me.Controls.Add(Me.txtHargaBeli)
        Me.Controls.Add(Me.txtNamaBarang)
        Me.Controls.Add(Me.txtKodeBarang)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnTambahSatuan)
        Me.Controls.Add(Me.btnSimpanKategori)
        Me.Controls.Add(Me.txtSatuan)
        Me.Controls.Add(Me.txtJenisProduk)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Label1)
        Me.DoubleBuffered = True
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents TransaksiToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProdukToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtJenisProduk As TextBox
    Friend WithEvents txtSatuan As TextBox
    Friend WithEvents btnSimpanKategori As Button
    Friend WithEvents btnTambahSatuan As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txtKodeBarang As TextBox
    Friend WithEvents txtNamaBarang As TextBox
    Friend WithEvents txtHargaBeli As TextBox
    Friend WithEvents cmbKategoriBarang As ComboBox
    Friend WithEvents cmbSatuanBarang As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents txtHargaJual As TextBox
    Friend WithEvents txtSaldoAwal As TextBox
    Friend WithEvents btnSimpanProduk As Button
    Friend WithEvents ErrorProvider1 As ErrorProvider
End Class
